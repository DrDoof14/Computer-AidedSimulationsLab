from cmath import pi
import random
import numpy as np
from time import time
import matplotlib.pyplot as plt
from scipy.stats import rice, norm

#set the random seed using my id student number
random.seed(300751)

class Routines:
    """
        Class of the routines to generate:
        - Bin(n,p) with the convolution method
        - Bin(n,p) with the inverse-transform method
        - Bin(n,p) with the third method explained during the lecture
        - N(mu, sigma**2) with the acceptance/rejection method
        - Poisson(a)
        - Chi-square(n)
        - Rice(nu, sigma) using Poisson and Chi-square
    """
    def convolution(n,p):
        x = 0
        for _ in range(n):
            u = random.uniform(0,1)
            if u < p:
                x = x+1
        return x

    def inverse_transform(n,p):
        A = []
        log_n_f = sum(np.log(range(1,n)))
        for x in range(n):
            log_x_f = sum(np.log(range(1,x)))
            log_nmx_f = sum(np.log(range(1,n-x)))
            value = np.exp(log_n_f-log_x_f-log_nmx_f+x*np.log(p)+(n-x)*np.log(1-p))
            A.append(value)
        u = random.uniform(0,1)
        for i in range(len(A)-1):
            if u >= A[i] and u<A[i+1]:
                return i     

    def method_3(n,p):
        m = 1
        q = 0
        for _ in range(n):
            u = random.uniform(0,1)
            g = np.ceil(np.log(u)/np.log(1-p))
            q = q+g
            if q > n:
                return m-1
            else:
                m = m+1
    
    def normal(k, mu=0, sigma2=1, a=-1, b=1):
        x = []
        res = []
        for _ in range(k):
            x.append(random.uniform(a,b))
        
        for i in range(k):
            y = random.uniform(0,max(x))
            value = x[i]
            pdf = (1/np.sqrt(2*pi*sigma2))*np.exp((-(value-mu)**2)/(2*sigma2))
            if y<=pdf:
                res.append(value)
        return res

    def poisson(a):
        n = 0
        q = 1
        while True:
            u = random.uniform(0,1)
            q = q*u
            if q < np.exp(-a):
                return n
            else:
                n = n+1
    
    def chi_square(n):
        normals = Routines.normal(k = n)
        for i in range(len(normals)):
            normals[i] = normals[i]**2
        return sum(normals)

    def rice(nu, sigma):
        p = Routines.poisson(nu**2/(2*sigma**2))
        x = Routines.chi_square(2*p+2)
        r = sigma*np.sqrt(x)
        return r
        
def main():

    print("===== BINOMIAL =====")
    """
        To simulate Bin(n,p) with different methods.
        We take trace of the time that each simulation takes.
        Pay attention that with the case n = 1000000, p = 1e-5, the simulations take really long time.
    """
    cases = [[10,0.5], [100, 0.01]]#, [100000, 1e-5]]
    t_conv = []
    t_it = []
    t_3 = []
    k = 100
    for case in cases:
        start = time()
        for _ in range(k):
            x_conv = Routines.convolution(case[0],case[1])
        end = time()
        t_conv.append(end-start)

        start = time()
        for _ in range(k):
            x_it = Routines.inverse_transform(case[0],case[1])
        end = time()
        t_it.append(end-start)

        start = time()
        for _ in range(k):
            x_3 = Routines.method_3(case[0],case[1])
        end = time()
        t_3.append(end-start)

    print(t_conv)
    print(t_it)
    print(t_3)
    plt.plot(range(len(t_conv)), t_conv)
    plt.plot(range(len(t_it)), t_it)
    plt.plot(range(len(t_3)), t_3)
    plt.title("Time to generate Bin(n,p)")
    plt.xlabel("Cases")
    plt.ylabel("Time of execution")
    plt.legend(labels = ["Convolution", "Inverse Transform", "3rd method"])
    plt.show()
    
    print("===== NORMAL =====")
    
    """
        To simulate N(0,1) distribution.
        There are also the pdfs plotted according to the simulated values.
        As requested, each plot is the comparison with respect to the theory.
    """

    mu = 0
    sigma2 = 1
    a = -1
    b = 1
    k = 100
    
    x = Routines.normal(k,mu, sigma2, a, b)

    x_es = np.linspace(mu - sigma2, mu + sigma2, 100)
    plt.plot(x_es, norm.pdf(x_es, mu, sigma2))
    plt.scatter(x, norm.pdf(x, mu, sigma2), marker = 'o', color = 'r')
    plt.title('Distribution of generated points wrt real distribution', fontsize=14)
    plt.xlabel('x')
    plt.ylabel('pdf(x)')
    plt.show()

    # line graph
    x.sort()
    z = [norm(0,1).pdf(val) for val in x]
    plt.plot(x,z)
    plt.title('Distribution of generated points', fontsize=14)
    plt.xlabel('x')
    plt.ylabel('pdf(x)')
    plt.show()

    # bar graph
    plt.bar(x, z, color ='blue', width = 0.4)
    plt.title('Distribution of generated points', fontsize=14)
    plt.xlabel('x')
    plt.ylabel('pdf(x)')
    plt.show()

    # cumulant
    cdf = np.cumsum(z)
    plt.plot(x, cdf, label="CDF")
    plt.title('Distribution of generated points', fontsize=14)
    plt.xlabel('x')
    plt.ylabel('pdf(x)')
    plt.show()
    
    print("===== RICE =====")

    """
        To simulate the rice distribution with different values for nu.
        There are also the pdfs plotted according to the simulated values and the different nu.
    """
    sigma = 1
    nu = [0,0.5,1,2,4]
    diz = {}
    
    k = 100
    for el in nu:
        results = []
        for _ in range(k):
            results.append(Routines.rice(el, sigma))
        diz[el] = results

    
    for el in nu:
        diz[el].sort()
        pdf_rice = rice.pdf(diz[el], sigma)
        plt.plot(diz[el], pdf_rice, label="PDF")
        plt.title(f'Rice distribution of generated points, nu = {el}', fontsize=14)
        plt.xlabel('x')
        plt.ylabel('pdf(x)')
        plt.grid(True)
        plt.show()

if __name__ == "__main__":
    main()




