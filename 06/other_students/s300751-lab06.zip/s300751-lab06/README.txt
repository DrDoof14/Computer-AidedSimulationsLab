There are 2 main parts:
- the Routines class, that contains all the routines to simulate all the requested distributions;
- the main in which we run all our simulations:
	- first, you can see the simulation of Bin(n,p) with three different methods, comparing the times;
	- secondly, there is the simulation of N(0,1) and you can have a look at the plots of the comparison between the empirical results and the theoretical ones;
	- finelly, the simulation of the Rice(nu, sigma2) distribution with the plots the different pdfs with respect to different values of nu.
