The zip contains three additional files: the  .ipynb of google-colab , the .py version of the code，the real data of distribution .text file and the report.
I'd suggest to directly look at the .ipynb file, as it already presents all the results without needing to run it
if not possible, you can run the .py file with block one by one.
In case, take into account that on a fast PC the whole code takes several minutes to run; to reduce this time, it is possible to change the simulation time of variable created for each method