from utils import *

lambda_values = [0.6,0.8,0.9,0.95,0.99,1.01,1.05,1.1,1.3]


for lambda_val in lambda_values:
    print(f"Lambda = {lambda_val}")
    print(f"Generated tree : {generate_tree(lambda_val)}")
    print(f"Exctintion probability within generation i (q_i) : {get_q_i(lambda_val)}")
    print(f"Asymptotic extinction  probability : {get_q(lambda_val)}")
    print("")
    print("")

####### 
# GRAPHS

# Exctintion probability within generation i (q_i)
print(plot_extintion_prob_qi(lambda_values))

# Empirical distribution (histogram) on the number of nodes in the tree , lambda = 0.8
print(plot_histogram(0.8))







