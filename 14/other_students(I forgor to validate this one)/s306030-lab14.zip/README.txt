### DESCRIPTION OF FILES ### 
main.py : source code of the simulator. This file has the main loops to compute the metrics requested. On top of the file you can set the parameters so DO NOT PASS THEM from terminal. Each parameters is explained in the comment next to it and below here. To run the code just run the main.py in the terminal or press play in IDE like PyCharm

### PARAMETERS ###
LAMBDAS = [0.6, 0.8, 0.9, 0.95, 0.99, 1, 1.01, 1.05, 1.1, 1.3]  # Lambdas to test
START_SEED = 18  # Seed for reproducibility. It changes on each generation
NUM_TREES = 1000  # Number of trees to generate in parallel = Number of experiments
MAX_GENERATION = 40  # Maximum number of generations to simulate

