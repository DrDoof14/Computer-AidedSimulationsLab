import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
from math import sqrt, exp

LAMBDAS = [0.6, 0.8, 0.9, 0.95, 0.99, 1, 1.01, 1.05, 1.1, 1.3]  # Lambdas to test
START_SEED = 18  # Seed for reproducibility. It changes on each generation
NUM_TREES = 1000  # Number of trees to generate in parallel = Number of experiments
MAX_GENERATION = 40  # Maximum number of generations to simulate


def generate_tree(n):
    """ Generate a tree with n nodes. It is a list of roots set to 1 """
    return n * [1]


def generate_child(parent, lambda_):
    """ Generate a child from a parent. Each child is generated from a Poisson distribution with parameter lambda_ """
    if parent == 0:  # If parent is extinct, child is also extinct
        return 0
    n_children = sum([np.random.poisson(lambda_) for _ in range(parent)])  # Parent is the number of nodes to generate
    return n_children


def next_generation(trees, lambda_):
    """ Generate the next generation of trees """
    new_generation = []
    for tree in trees:
        new_generation.append(generate_child(tree, lambda_))
    return new_generation


def count_extinctions(trees):
    """ Count the number of extinct trees """
    return np.sum([1 if tree == 0 else 0 for tree in trees])
    # return trees.count(0)


def get_PMF_poisson(lambda_, k=0):
    """ Get the probability mass function of a Poisson distribution with parameter lambda_ """
    return (lambda_ ** k) * exp(-lambda_) / np.math.factorial(k)


def get_PGF(lambda_: float, z: float):
    """ Get the probability generating function of a Poisson distribution with parameter lambda_ """
    return exp(lambda_ * (z - 1))


def get_conf_int_prob(p, n_exp, confidence=0.95):
    """ Get the confidence interval of a probability p on n experiments """
    s = sqrt((p * (1 - p)) / n_exp)
    alpha = 1 - confidence
    z_alpha = norm.ppf(1 - alpha / 2)
    return p - s * z_alpha, p + s * z_alpha


def plot_probs(x, data):
    fig1 = plt.figure(1, (13, 7))
    for i, lambda_ in enumerate(LAMBDAS):
        y = data[lambda_]["q_i"]
        stop = len(y)  # Early stopping based on end of transient
        conf_int_low = data[lambda_]["confint_low_i"]
        conf_int_up = data[lambda_]["confint_up_i"]
        plt.plot(x[:stop], y, label=f"λ = {lambda_}")
        plt.fill_between(x[:stop], conf_int_low, conf_int_up, alpha=0.1)
        # plt.plot(x[:stop], data[lambda_]["pgf"], linestyle="dashed", color="black")

    plt.xlabel("Number of generations")
    plt.ylabel("Probability of extinction")
    plt.title("Probability of extinction of a Galton-Watson process with children generated from Poisson distribution. "
              "Confidence interval at 95%")
    plt.legend()
    plt.grid()
    plt.xlim(1)
    plt.show()


def plot_asymptotic_probs(x, data):
    fig2 = plt.figure(2, (13, 7))
    for i, lambda_ in enumerate(LAMBDAS):
        if lambda_ > 1:
            y = data[lambda_]["pgf"]
            stop = len(y)  # Early stopping based on end of transient
            plt.plot(x[:stop], data[lambda_]["pgf"], label=f"λ = {lambda_}")

    plt.xlabel("Number of generations")
    plt.ylabel("Probability of extinction")
    plt.title("Asymptotic probability of extinction of a Galton-Watson process (Poisson distribution)")
    plt.legend()
    plt.grid()
    plt.xlim(1)
    plt.show()


def plot_hist_for_lambda(y, lambda_):
    fig3 = plt.figure(3, (13, 7))
    x_min = min(y) - 0.5
    x_max = max(y) + 0.5
    bins = np.arange(x_min, x_max, 1)
    plt.hist(y, bins=bins)
    plt.xlabel("Number of nodes")
    plt.ylabel("Frequency")
    plt.title(
        f"Frequency of number of nodes in a Galton-Watson process with children generated from Poisson distribution. "
        f"λ = {lambda_}")
    plt.grid()
    plt.xlim(0, 25)
    plt.show()


def get_metrics():
    """ Return the data structure to store the metrics """
    metrics = {}
    for lambda_ in LAMBDAS:
        metrics[lambda_] = {"q_i": [], "confint_up_i": [], "confint_low_i": [], "n_nodes": generate_tree(NUM_TREES),
                            "pgf": []}
    return metrics


def main():
    generations = np.arange(MAX_GENERATION + 1)
    metrics = get_metrics()

    for lambda_ in LAMBDAS:
        trees = generate_tree(NUM_TREES)  # Generate the initial trees [1, 1, 1, ..., 1]
        q_threshold = get_PMF_poisson(lambda_)  # Get the probability of extinction of a single tree
        for gen_i in generations:
            np.random.seed(START_SEED + NUM_TREES + gen_i)  # Change the seed for each experiment
            trees = next_generation(trees, lambda_)  # Generate the next generation of trees
            q_i = count_extinctions(trees) / NUM_TREES  # Compute the probability of extinction
            low, up = get_conf_int_prob(q_i, NUM_TREES)  # Compute the confidence interval for the probability
            # Store the metrics
            metrics[lambda_]["pgf"].append(get_PGF(lambda_, 0.0 if gen_i == 0 else metrics[lambda_]["pgf"][-1]))
            metrics[lambda_]["q_i"].append(q_i)
            metrics[lambda_]["confint_low_i"].append(low)
            metrics[lambda_]["confint_up_i"].append(up)
            metrics[lambda_]["n_nodes"] = np.sum([metrics[lambda_]["n_nodes"], trees], axis=0)

            if lambda_ > 1:  # Early stopping only on the supercritical regime case
                tmp = np.array([x for x in trees.copy() if x != 0])  # Remove the extinct trees
                avg_n_nodes = np.nanmean(tmp)  # Compute the average number of nodes alive
                prob_full_extinction = q_threshold ** avg_n_nodes  # Compute the probability of full extinction
                if prob_full_extinction < 10 ** -9:  # If probability of full extinction is very low, stop simulation
                    break

    # Plot the results
    plot_probs(generations, metrics)  # Plot the simulated probability of extinction
    plot_asymptotic_probs(generations, metrics)  # Plot the asymptotic probability of extinction (theorical)
    plot_hist_for_lambda(metrics[0.8]["n_nodes"], 0.8)  # Plot the histogram of the number of nodes for lambda = 0.8


if __name__ == '__main__':
    main()
