# Galton Watson process

Recreate my virtual environment using

```pip install -r requirements.txt```

To obtain all the required figures, just run

```python processor.py```
