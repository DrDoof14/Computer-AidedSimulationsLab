In oder to run the code open you terminal in the directory that you have the .py file and run the command below:
python lab16.py