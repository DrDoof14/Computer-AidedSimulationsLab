Confidence intervals are available both in the code and in the report
you easily run the code by writing
python lab10_new.py
in your terminal
 