In this zip file you can find two python codes:
- simulation.py 
- plotResults.py
and a pdf containing the requested graph with some comments.
To start the simulation you are requested to insert a input, you can follow the instruction given as output.
Instead the plotting code runs without any input.

Some useful assumptions taken when creating this simulation:
- the time is incremented in steps, at every end of the round it will be updated of 1 step;
- the only value acceptable for the mobility speed is 1. This means that at every end of round, so at every time increment, all the players will be moved;
- when considering the average killed enemies for all players it does not take into account the constraint of one minimum kill per player, so it is easily computer as ( total # initial player -1 )/ total # initial player;
- fights are 1 vs 1 and there will always a player dead.