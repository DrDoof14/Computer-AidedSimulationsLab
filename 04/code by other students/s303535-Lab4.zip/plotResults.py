import pandas as pd
import matplotlib.pyplot as plt
import os

csvName = ['depArenaSize.csv', 'depNPlayers.csv' , 'depMobSpeed.csv']
flag = True #boolena flag used to see if the csv files exist
for name in csvName: #check if all the needed files exist
    if not os.path.exists(name): #if not
        print('Not all the csv exist, please before run this code, generate all of them')
        flag = False #false flag and the code stops here
if flag == True:        
    #result of the simulation depending on the arena size
    dfArenaSize = pd.read_csv('depArenaSize.csv') 
    #result of the simulation depending on the initial number of players
    dfNPlayers = pd.read_csv('depNPlayers.csv')
    #result of the simulation depeding on the mobility speed
    #in my case not so meaningful because I've choose to have mobility speed = 1 always
    dfMobSpeed = pd.read_csv('depMobSpeed.csv')

    #create graphs
    yList = ['timeToWin', 'killsWinner', 'avgKills']
    xList = ['Arena', 'nPlayers', 'mobSpeed']

    for x in xList:
        for y in yList:
            if x == 'Arena':
                df = dfArenaSize[['Arena', y]]
            elif x == 'nPlayers':
                df = dfNPlayers[['nPlayers', y]]
            elif x == 'mobSpeed':
                df = dfMobSpeed[['mobSpeed', y]]
            if y == 'timeToWin':
                df.plot(x = y, y = x, c='g', legend = None, marker = 'o') #flip axes because i want time on the x
                plt.xlabel(y)
                plt.ylabel(x)
                plt.grid()
                plt.show()
            else:
                df.plot(x = x, y = y, c = 'g', legend = None, marker = 'o')
                plt.xlabel(x)
                plt.ylabel(y)
                plt.grid()
                plt.show()

