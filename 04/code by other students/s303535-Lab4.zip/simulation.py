import numpy as np
np.random.seed(480) #random seed
import time
import csv
import os

class Player():#player class

    def __init__(self, Id, isAlive, pos):
        self.Id = Id
        self.isAlive = isAlive #boolean flag to know if it is alive or not
        self.pos = pos #current position
        self.killedEnemies = 0 #number of killed enemies in a game
    
    def __str__(self): 
        return "Id: " + str(self.Id) +  "\nisAlive: " + str(self.isAlive) + "\nPosition: " + str(self.pos) 
    
    def __repr__(self):
        return "Id: " + str(self.Id) +  "\nisAlive: " + str(self.isAlive) + "\nPosition: " + str(self.pos) 
    
    def changePositions(self,n):#given a player it randomly replace it
         pos = np.random.randint(0,n,size=2)
         self.pos = pos

class Game(): #represinting class of a game

    def __init__(self, IdGame, n, nPlayers):
        self.IdGame = IdGame
        print('#############################')
        print('New game started, ID:', self.IdGame)
        print('With: n = ', n, 'nPlayers = ', nPlayers)
        self.n = n #n is the edge of the arena, so the area will be n*n
        self.nPlayers = nPlayers #initial number of players
        listPlayers = list() #list containing all the alive players
        for i in range(nPlayers): #here all the player are placed in the arena
            pos = np.random.randint(0,self.n,size=2)
            p = Player('p'+str(i), True, pos)  #player creation
            listPlayers.append(p) 
        self.listPlayers = listPlayers
        #print('Players all placed..')
      
    
    def fight(self): #function managing the fights 
        startIndex = 0 #index used to browsing inside the players list
        for i in range(startIndex,len(self.listPlayers)):
            for j in range(startIndex,len(self.listPlayers)):
                if(i!=j): #doing like this to check only once all the possible couples
                    p1 = self.listPlayers[i]
                    p2 = self.listPlayers[j]
                    #print('Coppie: ', p1.Id, p2.Id)
                    if p1.isAlive == True and p2.isAlive == True:
                        if self.isNear(p1.pos, p2.pos): #if 2 players are near, choose a winner
                            #print('Vicini :', p1.Id , p2. Id)
                            #print('Fight between: ', p1.Id, ' & ', p2.Id)
                            winner = self.winner(p1,p2)
                            #print('Winner:' , winner.Id, 'Killed Enemies: ', winner.killedEnemies)
            startIndex = startIndex + 1

    def isNear(self, pos1, pos2): #function checkinf if 2 players are near
        x1,y1 = pos1[0], pos1[1]
        x2,y2 = pos2[0], pos2[1]
        diffX, diffY = abs(x1 - x2), abs(y1 - y2)
        #here the criterion is: 2 players are near if they are in the same cell or at most in 2 consecutive cells 
        # (diagonal also accepted)
        if (diffX == 0 or diffX == 1) and (diffY == 0 or diffY == 1): 
            return True
        else:
            return False

    def winner(self,p1,p2): #function that draws a winner
        #arbitrary winning criterion:
        #draw a random number between 1 to 10
        #if even p1 wins otherwise p2
        i = np.random.randint(1,10) #11 because upper bound is excluded
        if (i%2 == 0): #p1 wins, p2 died
            p1.killedEnemies = p1.killedEnemies + 1 
            p2.isAlive = False 
            return p1 
        else: #p2 wins, p1 died
            p2.killedEnemies = p2.killedEnemies + 1 
            p1.isAlive = False
            return p2 

    def cleanUpdatePlayers(self,n): #here i remove the dead players and I update the positions for the alive ones
        #to use the player list updated in the next round
        for p in self.listPlayers:
            if p.isAlive == False:
                self.listPlayers.remove(p)
            else:
                p.changePositions(n)
        

def main():

    def updateCsv(dictList,csvName): #function used to create and write a csv to store run's statistics
        if os.path.exists(csvName):  #if the file already exists delete it 
            os.remove(csvName)
        csv_columns = ['Id', 'Arena', 'nPlayers', 'mobSpeed', 'timeToWin', 'killsWinner','avgKills']
        try:
            with open(csvName, 'a', newline = '') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
                writer.writeheader()
                for data in dictList:
                    writer.writerow(data)
                csvfile.close()
        except IOError:
            print("I/O error")

    mobilitySpeed = 1 #as assumption it can take only 1 as value
    IdGame = ['G1', 'G2', 'G3', 'G4'] 
    print('CHOOSE THE TYPE OF THE SIMULATION: ')
    print('0: Arena Size changes, nPlayers = 70, mobSpeed = 1')
    print('1: nPlayers changes, Arena Size = 100, mobSpeed = 1')
    print('2: mobility speed = 1, Arena Size = 100, nPlayers = 70')
    simType = input('Enter the selected number: ') #decision input
    dictList = list() #contains all the results dictionaries created in each game
    flag = True #boolean flag to see if the input is okay, if true it will be used to begin the sim loop

    if simType == '0': #dependency on arena size
        n = [10,15,20,30]
        nPlayers = [70,70,70,70] #aribitrary fixed 
        csvName = 'depArenaSize.csv'

    elif simType == '1': #dependency on initial number players
        nPlayers = [30,50,70,90]
        n = [10,10,10,10] #arbitrary fixed (n = edge of the arena)
        csvName = 'depNPlayers.csv'
    elif simType == '2':
        n = [10, 10, 10, 10]
        nPlayers = [70, 70, 70, 70]
        csvName = 'depMobSpeed.csv'
    else:
        print('Input not coherent')
        flag = False
    #in all cases mobility speed = 1

    #SIMULATION LOOP
    if flag == True:
        for edge,name,nP in zip(n,IdGame,nPlayers): #run 4 different games 
            g = Game(name, edge, nP)
            t = 0 #time in steps
            while len(g.listPlayers) != 1: #loop until i have only 1 player in the list --> it will be the winner
                g.fight() #recall the fight function
                g.cleanUpdatePlayers(edge) #clean the player list
                t = t +1 #update the time in steps
            #some useful prints
            print('WINNER OF THE GAME', name,':',g.listPlayers[0].Id, 'with', g.listPlayers[0].killedEnemies, 'killed enemies')
            print('Average killed enemies for all players:', (nP-1)/nP) #avg not taking into account the constraint of one minimum kill per player
            print('Time to win: (in steps)', t)
            #saving this game's statistics in a dict
            res = {'Id':name, 'Arena':edge*edge, 'nPlayers': nP, 'mobSpeed': 1, 'timeToWin': t, 'killsWinner': g.listPlayers[0].killedEnemies, 'avgKills':(nP-1)/nP}
            dictList.append(res) #save the dict in list (it will contain 4 dict, 1 dict for each game)

        updateCsv(dictList,csvName) #create csv
        print('CSV created:' , csvName)
    
    
if __name__ == "__main__":
    main()