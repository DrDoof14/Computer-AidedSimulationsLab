import numpy as np
import csv
import json
from tabulate import tabulate
from math import log

def random_dropping(n):
    #creation of the dictionary representing the bins
    #key = progressive number from 0 to n-1
    #value = number of balls in that specific bin
    keys = list(range(0,n)) 
    bins = dict.fromkeys(keys,0)
    for _ in range(n):
        idx = np.random.randint(0,n) #randomly choose one bin
        #0 included n excluded, but this is okay because we have positions from 0 to n-1 
        bins[idx] = bins[idx] + 1 #drop the ball in the selected bin (i.e. update the dict)
    values = bins.values()
    mean = 1 #from theory and from logic we know that the maen is always = 1
    return [min(values), max(values), mean] #return min, max, mean of the values

def load_balancing(n,d):
    #creation of the dictionary representing the bins
    #key = progessive number form 0 to n-1
    #value = number of balls in that specific bin
    keys = list(range(0,n))
    bins = dict.fromkeys(keys,0)
    for _ in range(n):
        idxs = np.random.randint(0,n,d) #select d random bins (indexes)
        sel_bins = {x:bins[x] for x in idxs} #from indexes retrieve the subdict of selected bins (it is a dict) 
        '''needed to proceed in this way because we have to manage also multiple bins iwht the same min value'''
        min_occ = min(sel_bins.values()) #select the min value of occupancy of the selected bins
        min_key = [i for i in sel_bins if sel_bins[i] == min_occ] #retrive the keys of the min value (min_key is a list of 1 or more values)
        if len(min_key) > 1: #if i have more keys associated to the min value i choose one of them and update the general dict
            i = np.random.randint(0,len(min_key))
            rand = min_key[i]
            bins[rand] = bins[rand] + 1
        else: #otherwise if one key has only the min value update it in the general dict
            bins[min_key[0]] = bins[min_key[0]] + 1
        values = bins.values()
        mean = 1 #from theory and from logic we know that the maen is always = 1
    return [min(values), max(values), mean] #return min, max, mean of the values
        
def compute_theoretical(cases_n):#function used to compute theoretical maximum occupancy
    #3 dicts one for each type of drop
    max_th_dropping = dict.fromkeys(cases_n,0)
    max_th_load2 = dict.fromkeys(cases_n,0)
    max_th_load4 = dict.fromkeys(cases_n,0)

    for n in cases_n:#formulas taken from lecture slide
        max_th_dropping[n] = round((3*log(n)/(log(log(n)))),2)
        max_th_load2[n] = round((log(log(n))/log(2)),2)
        max_th_load4[n] = round((log(log(n))/log(4)),2)
    
    return max_th_dropping, max_th_load2, max_th_load4

def create_json(dicts):#function to save statistics as json files
    names = ['avg_max_rnd_drop.json','avg_max_load2.json','avg_max_load4.json',
    'max_th_dropping.json', 'max_th_load2.json', 'max_th_load4.json']
    for dict,name in zip(dicts,names):
        # create json object from dictionary
        json_file = json.dumps(dict)
        # open file for writing, "w"
        f = open(name,"w")
        # write json object to file
        f.write(json_file)
        # close file
        f.close()


def main():
    seeds = [303535,40899,12345] #different seeds to run different experiments
    cases_n = [10,100,1000,10000,100000,1000000] #n taken in consideration
    #dictionaries used to store the avg max occupancy for each type of drop
    avg_dropping = dict.fromkeys(cases_n,0)
    avg_load2 = dict.fromkeys(cases_n,0)
    avg_load4 = dict.fromkeys(cases_n,0)

    max_th_dropping, max_th_load2, max_th_load4 = compute_theoretical(cases_n) #store theoretical results in 3 dictionaries

    for seed in seeds: #simulation loop 
        np.random.seed(seed)
        print('Seed:', seed)
        res_dropping = dict.fromkeys(cases_n,0)  #dict keys = n values = list(min,max,mean = 1) regarding the simulation with n bins & balls 
        res_load2 = dict.fromkeys(cases_n,0)
        res_load4 = dict.fromkeys(cases_n,0)
        for n in cases_n:
            #for each dict i save the results of the drop in the corresponding key to n
            res_dropping[n] = random_dropping(n)
            res_load2[n] = load_balancing(n,2)
            res_load4[n] = load_balancing(n,4)
            #first step to compute avg max occupancy ( sum all the results wrt n )
            avg_dropping[n] = avg_dropping[n] + res_dropping[n][1]
            avg_load2[n] = avg_load2[n] + res_load2[n][1]
            avg_load4[n] = avg_load4[n] + res_load4[n][1]

        print('Statistics Random Dropping [min,max,mean]' , res_dropping)
        print('Statistics Load Balancing d = 2 [min,max,mean]' , res_load2)
        print('Statistics Load Balancing d = 4 [min,max,mean]' , res_load4)
        print('########################\n')

    for n in cases_n:
        #second step to compute avg max occupancy fro each n compute the avg
        avg_dropping[n] = round(avg_dropping[n]/len(seeds), 2)
        avg_load2[n] = round(avg_load2[n]/len(seeds), 2)
        avg_load4[n] = round(avg_load4[n]/len(seeds), 2)
   
    print('#### AVG OF MAX OCCUPANCY ####')
    print('Random Dropping' , avg_dropping)
    print('Load Balancing d = 2' , avg_load2)
    print('Load Balancing d = 4' , avg_load4)
    
    
    dicts = [avg_dropping,avg_load2,avg_load4,max_th_dropping, max_th_load2, max_th_load4]
    create_json(dicts) #save as json all the dicts needed to create the comparison graph
    
if __name__ == '__main__':
    main()