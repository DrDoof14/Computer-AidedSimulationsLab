In the zip you'll find two .py files.
--s303535_Lab07_sim.py: this python file is to simulate and store results. 
To run it simply run the file and it'll show some statistics in the output cell.
It will also produce 6 json files used to pass data to the other python file in order to create 
the comparison graph.
--s303535_Lab07_read_json: it read all the json files created before and it will produce 
and save the graph in which compares the empirical and theoretical results for all the drops.
There are also all the json files with saved data used to create the plot, this because there might be problems with running time since the code considers n till 1 million.