# importing the module
import json
import matplotlib.pyplot as plt
import os

names_avg = ['avg_max_rnd_drop.json','avg_max_load2.json','avg_max_load4.json']
names_th= ['max_th_dropping.json', 'max_th_load2.json', 'max_th_load4.json']
flag = True #boolena flag used to see if the csv files exist

for name_avg,name_th in zip(names_avg,names_th): #check if all the needed files exist
    if (not os.path.exists(name_avg) ) and (not os.path.exists(name_th)): #if not
        flag = False #false flag and the code stops here
if flag == False:
  print('Not all the json exist, please before run this code, generate all of them (run s303535_Lab07_sim.py')
if flag == True:
        
  data_avg = list()
  data_th = list()

  # Opening JSON file
  for name in names_avg:
    with open(name) as json_file:
      #save data related to empirical results in one list
      data_avg.append(json.load(json_file)) #json.load(json_file) is a dict

  for name in names_th:
    with open(name) as json_file:
      #save data related to theoretical results in another list
      data_th.append(json.load(json_file)) #json.load(json_file) is a dict

  x = list(data_avg[0].keys()) #x axis will be always n 

  plt.rcParams['figure.figsize'] = [10, 5]
  for avg,label in zip(data_avg,['Em_Rd', 'Em_Lb2', 'Em_Lb4']):
      plt.plot(x,list(avg.values()),label=label,linestyle='dashed', marker = '*') #plot empirical

  for th,label in zip(data_th,['Th_Rd', 'Th_Lb2', 'Th_Lb4']):
      plt.plot(x,list(th.values()), label = label,marker = '.') #plot theoretical 

  plt.legend()
  plt.xlabel('n (number of bins/balls)')
  plt.ylabel('Max occupancy')
  plt.grid()
  plt.savefig('comparison.jpg')
  plt.show()
