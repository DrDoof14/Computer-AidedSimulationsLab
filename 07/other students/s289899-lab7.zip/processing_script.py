import numpy as np
import pandas as pd
from simulator import RandomDropping, RandomLoadBalancing
import math
from datetime import datetime
import time 
import seaborn as sns
from scipy.stats import t
import matplotlib.pyplot as plt


#Input parameters
runs = 8
bins = [100, 200, 400, 600, 800, 1000, 2000, 4000, 6000, 8000, 10000]
seed = 1800

#Simulations for Random Dropping
avgs = []
np.random.seed(seed) 
for b in bins:
    avg= RandomDropping(b, runs)
    avgs.append(avg)
#Output parameters
avgs = np.array(avgs)

#Simulations for Random Load Balancing with d = 2
avgs2 = []
np.random.seed(seed)
for b in bins:
  avg = RandomLoadBalancing(b, 2, runs)
  avgs2.append(avg)
    
#Output parameters
avgs2 = np.array(avgs2)

#Simulations for Random Load Balancing with d = 4
avgs4 = []
np.random.seed(seed)
for b in bins:
  avg = RandomLoadBalancing(b, 4, runs)
  avgs4.append(avg)

#Output parameters
avgs4 = np.array(avgs4)

#Plot1
fig, ax = plt.subplots(figsize=(20,10))

ax.plot(np.log10(bins), avgs, color = 'b', marker = 'o', label = 'Random Dropping')
ax.plot(np.log10(bins), avgs2, color = 'orange', marker = 'x', label = 'Random Load Balancing d = 2')
ax.plot(np.log10(bins), avgs4, color = 'g', marker = '^', label = 'Random Load Balancing d = 4')
ax.legend()
plt.xlabel('log10(Bins)')
plt.title('Simulation results')
plt.ylabel('Maximum occupancy')

def tRandomDropping(x):
  return 3*(np.log(x))/(np.log(np.log(x)))

#Plot2
fig, ax = plt.subplots(figsize=(20,10))
ax.plot(np.log10(bins), avgs, color = 'b', marker = 'o', label = 'Random Dropping')
ax.plot(np.log10(bins), tRandomDropping(bins), color = 'r', label = 'Theoretical upper bound')
plt.xlabel('log10(Bins)')
plt.title('Simulation results vs theoretical results')
plt.ylabel('Maximum occupancy')
plt.legend()

