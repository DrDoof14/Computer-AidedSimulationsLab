import numpy as np
import pandas as pd
import math
from datetime import datetime
import time 
from scipy.stats import t

def RandomDropping(n, runs):

  results = np.zeros(runs, )
  for r in range(runs):
    bins = np.zeros(n,)
    for b in range(n):
      index = np.random.randint(low = 0, high = n, size = 1)
      bins[index] = bins[index] + 1
    results[r] = max(bins)
  avg = np.average(results)
  return avg


def RandomLoadBalancing(n, d, runs):
  results = np.zeros(runs, )
  for r in range(runs):
    bins = np.zeros(n,)
    for b in range(n):
      indexes = np.random.randint(low = 0, high = n, size = d)
      minB = bins[indexes[0]]  
      minIdx = indexes[0]
      for i in range(d):
        if minB > bins[indexes[i]]:
          minIdx = indexes[i]
          minB = bins[indexes[i]]
      bins[minIdx] = bins[minIdx] + 1
    results[r] = max(bins)
  avg = np.average(results)

  return avg